// make sense only when GTP_HEADER_FW_UPDATE & GTP_AUTO_UPDATE are enabled
// define your own firmware array here
const unsigned char header_fw_array[] = 
{
    
};